import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
plt.rcParams['font.sans-serif'] = ['SimHei']
#############预处理
perior='2016'
file=perior+'.xlsx'
sup=0.2
thres=0.2


# 假设读取的表格存储在一个 DataFrame 中
data = pd.read_excel('./data/'+file)

# 提取关键词列，选择其中一个方法，例如 '关键词(TF-IDF)'
keyword_columns = ['关键词(TF-IDF)', '关键词(TextRank)', '关键词(我们的方法)']
new_col = ['t(TF-IDF)', 't(TextRank)', 't(我们的方法)']
def preprocess(col,new_col):
    temp_list = []
    data[new_col] = None 
    cur=0
    for i in range(len(data)):
        # 检查当前行是否第一行
        if not pd.isnull(data.at[i, '原句']):
            cur=i

        if not data.iloc[i].isnull().all():
            if not pd.isnull(data.at[i, col]):
            # 记录 D, E, F 列的数据到临时列表中
                temp_list.append(data.at[i, col])
        else:
            data.at[cur,new_col]=temp_list
            temp_list = []
    # 处理最后一组数据
    if temp_list :
        data.at[cur,new_col]=temp_list

#处理三种方法的关键词
for i in range(3):
    preprocess(keyword_columns[i],new_col[i])
# data.to_excel('./processed/'+file, index=False)
# 删除 A 列为空的行
data = data.dropna(subset=['原句'])
data = data.drop(columns=['分词','词频','关键词(TF-IDF)','关键词(TextRank)','关键词(我们的方法)'])


from mlxtend.frequent_patterns import fpgrowth, association_rules, apriori
from mlxtend.preprocessing import TransactionEncoder
# 使用 TransactionEncoder 转换事务数据
te = TransactionEncoder()
te_ary = te.fit(data[new_col[2]]).transform(data[new_col[2]])

# 将转换后的数据转为 DataFrame
df_encoded = pd.DataFrame(te_ary, columns=te.columns_)


#############################算法时间对比

# 线性切分的 min_support_values
min_support_values = list(np.linspace(0.01, 0.05, 100))
min_threshold_values = list(np.linspace(0.2, 0.5, 5))

# 存储结果
apriori_times = []
fpgrowth_times = []
frequent_itemsets_counts = []
rules_counts = []

# 遍历不同的min_support和min_threshold值
for min_support in min_support_values:
    for min_threshold in min_threshold_values:
        # 记录开始时间
        start_time = time()
        # 使用 Apriori 查找频繁项集
        frequent_itemsets_apriori = apriori(df_encoded, min_support=min_support, use_colnames=True)
        # 使用 association_rules 生成关联规则
        rules_apriori = association_rules(frequent_itemsets_apriori, min_threshold=min_threshold)
        apriori_time = time() - start_time  # 计算 Apriori 算法的执行时间
        
        # 记录 Apriori 结果
        apriori_times.append(apriori_time)
        frequent_itemsets_counts.append(len(frequent_itemsets_apriori))
        rules_counts.append(len(rules_apriori))
        
        # 记录开始时间
        start_time = time()
        # 使用 FPGrowth 查找频繁项集
        frequent_itemsets_fpgrowth = fpgrowth(df_encoded, min_support=min_support, use_colnames=True)
        # 使用 association_rules 生成关联规则
        rules_fpgrowth = association_rules(frequent_itemsets_fpgrowth, min_threshold=min_threshold)
        fpgrowth_time = time() - start_time  # 计算 FPGrowth 算法的执行时间
        
        # 记录 FPGrowth 结果
        fpgrowth_times.append(fpgrowth_time)

# 创建 DataFrame 来存储结果
result_df = pd.DataFrame({
    'min_support': [min_support for min_support in min_support_values for _ in min_threshold_values] * 2,
    'min_threshold': min_threshold_values * len(min_support_values) * 2,
    'algorithm': ['Apriori'] * len(min_support_values) * len(min_threshold_values) + ['FPGrowth'] * len(min_support_values) * len(min_threshold_values),
    'frequent_itemsets_count': frequent_itemsets_counts * 2,
    'rules_count': rules_counts * 2,
    'execution_time': apriori_times + fpgrowth_times
})

# 绘制 Apriori 和 FPGrowth 算法的执行时间
plt.figure(figsize=(12, 6))
for algorithm in ['Apriori', 'FPGrowth']:
    filtered_df = result_df[result_df['algorithm'] == algorithm]
    plt.plot(filtered_df['min_support'], filtered_df['execution_time'], label=algorithm)

plt.title('Execution Time of Apriori and FPGrowth Algorithms')
plt.xlabel('Min Support')
plt.ylabel('Execution Time (seconds)')
plt.legend()
plt.show()






#######################挖掘并画饼状图
# # 使用 FP-growth 查找频繁项集
# frequent_itemsets = fpgrowth(df_encoded, min_support=sup, use_colnames=True)


# # 使用 association_rules 生成关联规则
# rules = association_rules(frequent_itemsets, min_threshold=thres)

# # 去除双向重复的规则
# def remove_redundant_rules(rules_df):
#     # 规范化规则（排序antecedents和consequents）
#     rules_df['sorted_rule'] = rules_df.apply(
#         lambda row: tuple(sorted(set(row['antecedents']).union(set(row['consequents'])))), axis=1
#     )
    
#     # 去除重复规则
#     unique_rules = rules_df.drop_duplicates(subset='sorted_rule')
    
#     return unique_rules

# # 去除重复规则
# rules = remove_redundant_rules(rules)



# # 保存前10条关联规则
# rules_top10 = rules.sort_values(by='support', ascending=False).head(10)
# rules_top10.to_csv(perior+'rules_top10.csv', index=False)




# # 绘制关联规则的支持度饼状图
# # 创建一个新的列，组合antecedents和consequents
# rules_top10['rule'] = rules_top10['antecedents'].apply(lambda x: '_'.join(list(x))) + ' => ' + rules_top10['consequents'].apply(lambda x: '_'.join(list(x)))

# # 绘制关联规则的支持度饼状图
# rules_top10['support'].plot(kind='pie', labels=rules_top10['rule'], autopct='%1.1f%%', figsize=(8, 8), startangle=90,
#                              fontsize=14)
# plt.title(perior+' Top 10 Association Rules by Support')
# plt.ylabel('')  # 去除y轴标签
# plt.show()







# #####################################关联规则矩阵
#  创建一个矩阵用于可视化
rule_matrix = pd.pivot_table(rules, values='lift', index='antecedents', columns='consequents', fill_value=0)

# 绘制热力图
plt.figure(figsize=(10, 8))
sns.heatmap(rule_matrix, annot=True, cmap='YlGnBu')
plt.title("Heatmap of Association Rules")
plt.show()



# # 线性切分的 min_support_values
# min_support_values = list(np.linspace(0.2, 0.05, 20))
# min_threshold_values = list(np.linspace(0.1, 0.5, 10))

# # 存储结果
# frequent_itemsets_counts = []
# rules_counts = []

# # 遍历不同的min_support和min_threshold值
# for min_support in min_support_values:
#     for min_threshold in min_threshold_values:
#         # 使用 FP-growth 查找频繁项集
#         frequent_itemsets = apriori(df_encoded, min_support=min_support, use_colnames=True)
#         # frequent_itemsets = fpgrowth(df_encoded, min_support=min_support, use_colnames=True)
        
#         # 使用 association_rules 生成关联规则
#         rules = association_rules(frequent_itemsets, min_threshold=min_threshold)
        
#         # 记录频繁项集和关联规则的数量
#         frequent_itemsets_counts.append(len(frequent_itemsets))
#         rules_counts.append(len(rules))

# # 创建 DataFrame 来存储结果
# result_df = pd.DataFrame({
#     'min_support': [min_support for min_support in min_support_values for _ in min_threshold_values],
#     'min_threshold': min_threshold_values * len(min_support_values),
#     'frequent_itemsets_count': frequent_itemsets_counts,
#     'rules_count': rules_counts
# })

# # 绘制结果图
# fig, ax = plt.subplots(1, 2, figsize=(14, 6), gridspec_kw={'width_ratios': [1, 2]})

# # 绘制频繁项集数量的热力图
# pivot_frequent_itemsets = result_df.pivot(index='min_support', columns='min_threshold', values='frequent_itemsets_count')
# cax1 = ax[0].imshow(pivot_frequent_itemsets, cmap='viridis', aspect='auto')

# # 设置坐标轴
# ax[0].set_xticks(range(len(min_threshold_values)))
# ax[0].set_xticklabels([f'{x:.3f}' for x in min_threshold_values])  # 限制为1位小数
# ax[0].set_yticks(range(len(min_support_values)))
# ax[0].set_yticklabels([f'{x:.3f}' for x in min_support_values])  # 限制为1位小数
# ax[0].set_title('Frequent Itemsets Count')
# ax[0].set_xlabel('min_threshold')
# ax[0].set_ylabel('min_support')

# # 添加颜色条
# fig.colorbar(cax1, ax=ax[0])

# # 绘制关联规则数量的热力图
# pivot_rules = result_df.pivot(index='min_support', columns='min_threshold', values='rules_count')
# cax2 = ax[1].imshow(pivot_rules, cmap='viridis', aspect='auto')

# # 设置坐标轴
# ax[1].set_xticks(range(len(min_threshold_values)))
# ax[1].set_xticklabels([f'{x:.3f}' for x in min_threshold_values])  # 限制为1位小数
# ax[1].set_yticks(range(len(min_support_values)))
# ax[1].set_yticklabels([f'{x:.3f}' for x in min_support_values])  # 限制为1位小数
# ax[1].set_title('Rules Count')
# ax[1].set_xlabel('min_threshold')
# ax[1].set_ylabel('min_support')

# # 添加颜色条
# fig.colorbar(cax2, ax=ax[1])

# plt.tight_layout()
# plt.show()

#########################导入neo4j
from py2neo import Graph
from py2neo import Node, Relationship
import config
# 连接到本地 Neo4j 数据库
graph = Graph("bolt://172.17.0.3:7687", auth=("neo4j", config.passwd))
# 清空数据库（可选，确保图清晰）
graph.delete_all()
# 导入关联规则到 Neo4j
for index, row in rules.iterrows():
    # 创建前项和后项的节点
    antecedent = "_".join(row['antecedents'])
    consequent = "_".join(row['consequents'])
    
    # 如果节点不存在则创建
    antecedent_node = Node("Item", name=antecedent)
    consequent_node = Node("Item", name=consequent)
    
    # 创建规则的关系
    rule = Relationship(antecedent_node, "IMPLIES", consequent_node)
    rule["lift"] = row['lift']
    rule["confidence"] = row['confidence']
    rule["support"] = row['support']
    
    # 将节点和关系添加到图数据库
    graph.merge(antecedent_node, "Item", "name")
    graph.merge(consequent_node, "Item", "name")
    graph.create(rule)

from collections import Counter
import matplotlib.font_manager as fm

#######################向量化并输出excel
# 读取关键词字典
# df_keywords = pd.read_excel('data/关键词词典.xlsx', header=None)
# keywords = df_keywords[0].tolist()

# # 构建词袋模型
# keyword_dict = {word: idx for idx, word in enumerate(keywords)}

# # 假设df句子数据框已经存在，其中包含句子及其提取出的关键词
# df = data  # 假设'data'是已有的DataFrame

# # 初始化句子向量化结果
# vectorized_sentences = []

# # 假设新列名是 '关键词'，根据实际数据框的列名调整
# for sentence_keywords in df[new_col[2]]:
#     # 创建一个零向量，长度为词典大小
#     vector = np.zeros(len(keywords), dtype=int)
    
#     # 遍历句子中的关键词，更新向量
#     keyword_count = Counter(sentence_keywords)
#     for keyword, count in keyword_count.items():
#         if keyword in keyword_dict:
#             vector[keyword_dict[keyword]] = count  # 设置该关键词对应位置的计数
    
#     vectorized_sentences.append(vector)

# # 创建一个新的DataFrame，包含句子及其对应的向量
# vector_df = pd.DataFrame(vectorized_sentences)

# # 将句子和向量合并到同一个DataFrame
# df_output = pd.concat([df['原句'], vector_df], axis=1)

# # 将合并后的DataFrame输出到Excel文件
# output_file = '句子与向量.xlsx'
# df_output.to_excel(output_file, index=False, engine='openpyxl')

# print(f'句子与向量已成功输出到 {output_file}')

#############################向量化并聚类
# 读取关键词字典
df_keywords = pd.read_excel('data/关键词词典.xlsx', header=None)
keywords = df_keywords[0].tolist()

# 构建词袋模型
keyword_dict = {word: idx for idx, word in enumerate(keywords)}

# 假设df句子数据框已经存在，其中包含句子及其提取出的关键词
df = data

# 初始化句子向量化结果
vectorized_sentences = []

for sentence_keywords in df[new_col[2]]:
    # 创建一个零向量，长度为词典大小
    vector = np.zeros(len(keywords), dtype=int)
    
    # 遍历句子中的关键词，更新向量
    keyword_count = Counter(sentence_keywords)
    for keyword, count in keyword_count.items():
        if keyword in keyword_dict:
            vector[keyword_dict[keyword]] = count  # 设置该关键词对应位置的计数
    
    vectorized_sentences.append(vector)

# 输出向量化的句子
print(np.array(vectorized_sentences))
print(df['原句'])

from scipy.cluster.hierarchy import dendrogram, linkage, fcluster
from sklearn.metrics import silhouette_score
# 2. 使用层次聚类（凝聚型）
Z = linkage(vectorized_sentences, method='ward')  # 'ward' 是常用的聚类方法，最小化簇内的方差centroid single

# 3. 绘制树状图
fig, (ax1, ax2,ax3,ax4,ax5) = plt.subplots(1, 5, figsize=(30, 30))
dendrogram(Z, labels=df['原句'].tolist(), orientation='left', leaf_font_size=15,ax=ax1)
# 设置标题
ax1.set_title("Hierarchical Clustering Dendrogram")

# 留空的第二个子图
ax2.axis('off')
ax3.axis('off')
ax4.axis('off')
ax5.axis('off')

# 展示图形
plt.show()

# 根据树状图的距离设定阈值进行聚类
# 这里的10是指定的聚类数，也可以根据树状图动态设定
max_d = 10  # 可调节的簇数
clusters = fcluster(Z, max_d, criterion='maxclust')

# 将聚类结果添加到原数据中（假设每行对应一个句子）
df_clusters = pd.DataFrame(vectorized_sentences)
df_clusters['Cluster'] = clusters

# 定量分析
# 计算每个簇的均值和方差
cluster_summary = df_clusters.groupby('Cluster').agg(['mean', 'std'])

# 打印聚类的均值和方差
print("Cluster Summary (Mean and Std Dev):")
print(cluster_summary)

# 计算轮廓系数（Silhouette Score）来评估聚类质量
sil_score = silhouette_score(vectorized_sentences, clusters)
print(f"Silhouette Score: {sil_score:.4f}")